#include <iostream>
using namespace std;


int main()
{
	int number;
	cout << "enter a number" << endl;
	cin >> number;

	unsigned int mask = 1; // set lowest bit
	mask = mask << 30; // Move up to topmost bit

	for( int i = 1; i< 32; i++ )
	{
		if( mask & number )
		{
			cout << 1;
		}
		else
		{
			cout << 0;
		}
		number = number << 1; // shift number up by 1
		if( i % 8 == 0 )
		{
			cout << " ";
		}
	}
	cout << endl;
	system( "pause" );
}




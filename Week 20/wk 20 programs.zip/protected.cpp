#include <iostream>
using namespace std;


class CBase
{
protected:
	int mData;
	CBase( int data): mData( data ) {};
	void Display() { cout << mData << endl; };
};

class CDerived : public CBase
{
public:
	CDerived( int data ) : CBase( data ) { } ;
	void NewDisplay(){ cout << mData << endl; };
};

int main()
{
	CDerived* derived = new CDerived( 5);
	derived->NewDisplay();
	delete derived;


	system( "pause" );

}


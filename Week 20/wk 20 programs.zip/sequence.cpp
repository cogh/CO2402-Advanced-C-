#include <iostream>
using namespace std;

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

class CBase
{
public:
	CBase( );
	~CBase( );
};

CBase::CBase( )
{
	cout << "Base constructor called\n";
}

CBase::~CBase( )
{
	cout << "Base destructor called\n";
}


class CDerived : public CBase
{
public:
	CDerived( );
	~CDerived( );
};

CDerived::CDerived( )
{
	cout << "Derived constructor called\n";
}

CDerived::~CDerived( )
{
	cout << "Derived destructor called\n";
}

int main()
{
	_crtBreakAlloc=-1;

	CDerived* derived = new CDerived;
//	CBase* base = new CBase;


	delete derived;
//	delete base;

	system( "pause" );

    _CrtDumpMemoryLeaks();
}


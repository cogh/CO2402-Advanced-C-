#include <iostream>
using namespace std;

class CTest
{
private:
	static int single;
public:
	void SetStatic( int data );
	int GetStatic(  );
};

int CTest::single = 4;

void CTest::SetStatic( int data )
{
	single = data;
}

int CTest::GetStatic(  )
{
	return single;
}

int main()
{
	CTest* myTest = new CTest;
	cout << myTest->GetStatic( ) << endl;
	myTest->SetStatic( 7 );
	cout << myTest->GetStatic( ) << endl;

	system( "pause" );

}

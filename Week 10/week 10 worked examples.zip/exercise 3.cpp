#include <iostream>
using namespace std;

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

class Memory
{
private:
	int count;
public:
	Memory();
	void* Allocate( size_t size);
	void Deallocate( void* ptr );
	int NumberOfAllocations( );
};

Memory::Memory()
{
	count = 0;
}

void* Memory::Allocate( size_t size)
{
	count++;
	return malloc( size);
}

void Memory::Deallocate( void* ptr )
{
	count--;
	free( ptr );
}

int Memory::NumberOfAllocations( )
{
	return count;
}

int main()
{
	Memory myMemory;

	int* i = (int*) myMemory.Allocate( sizeof( int ) );
	*i = 4;
	cout << *i << endl;
	cout << myMemory.NumberOfAllocations() << endl;

	myMemory.Deallocate( i );
	cout << myMemory.NumberOfAllocations() << endl;

	// Note that line number is provided by the macro
	// __LINE__

	// Dump memory leaks to output window.
    _CrtDumpMemoryLeaks();
	system( "pause" );
}


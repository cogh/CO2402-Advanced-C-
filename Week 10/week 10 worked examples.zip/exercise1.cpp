#include <iostream>
using namespace std;

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

class Test
{
private:
	int data;
public:
	void setData( int d );
	void callByReference( int* d );
	void callUsingReferenceParameter( int& d );
	void callByCopy( int d );
};

void Test::setData( int d )
{
	data = d;
}
void Test::callByReference( int* d )
{
	*d = data;
}

void Test::callUsingReferenceParameter( int& d )
{
	d = data;
}

void Test::callByCopy( int d )
{
	d = data;
}

int main()
{
    _CrtDumpMemoryLeaks();

	Test* t = new Test;
	int i;

	t->setData( 5 );

	i = 4;
	t->callByCopy( i );
	cout << i << endl;

	i = 4;
	t->callByReference( &i );
	cout << i << endl;

	i = 4;
	t->callUsingReferenceParameter( i );
	cout << i << endl;

	system( "pause" );
}

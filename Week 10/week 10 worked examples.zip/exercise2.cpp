#include <iostream>
using namespace std;

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

class StoreArray
{
private:
	int* arrayPtr;
public:
	StoreArray();
	void displayArray();
	~StoreArray();
};

StoreArray::StoreArray()
{
	arrayPtr = new int[4];	// Create the array

	for( int i = 0; i< 4; i++ )
	{
		arrayPtr[i] = i * 2;
	}
}

void StoreArray::displayArray()
{
	for( int i = 0; i< 4; i++ )
	{
		cout << arrayPtr[i] << " ";
	}
	cout << endl;
}

StoreArray::~StoreArray()
{
	delete [ ] arrayPtr;		// Delete the array
}

int main()
{
	StoreArray* myStoreArray = new StoreArray;

	myStoreArray->displayArray();

	delete ( myStoreArray );
    _CrtDumpMemoryLeaks();
	system( "pause" );
}

// Demonstration of the need for a user created copy constructor
// Successful behaviour implemented by the use of deep copy.

#include <iostream>
using namespace std;

class CValue
{
private:
	int* mpData;
public:
	CValue( const CValue& theOriginal );
	CValue( ) { mpData = new int; };
	void Set( int data ) { *mpData = data; };
	void Display( ) { cout << *mpData << endl; };
};

CValue::CValue( const CValue& theOriginal )
{
	cout << "copy constructor called" << endl;
	mpData = new int;
	*mpData = *theOriginal.mpData;
}

void foo( CValue copy )
{
	cout << "copy in foo: ";
	copy.Display(); // Output: 2

	copy.Set( 3 );

	cout << "copy in foo: ";
	copy.Display(); // Output: 3
}

void main()
{
	CValue original;

	original.Set( 2 );
	cout << "original: ";
	original.Display(); // Output: 2

	foo( original );

	cout << "original: ";
	original.Display(); // Output: 3! NOT WHAT WE WANT!

	system( "pause" );
}

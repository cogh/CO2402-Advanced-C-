// Demonstration of the need for a user created copy constructor
// Successful behaviour implemented by the use of deep copy.
// Overridden the assignment operator in order to implement this.

#include <iostream>
using namespace std;

class CPointer
{
private:
	int* mpData;
public:
	CPointer operator = ( const CPointer& );

	CPointer( )
		{	mpData = new int; };
	void Set( int data )
		{	*mpData = data; };
	void Display( )
		{	cout << *mpData << endl; };
};

CPointer CPointer::operator = ( const CPointer& operand )
{
	cout << "assignment operator called\n";
	*mpData = *operand.mpData;

	return *this;
}

void main()
{
	CPointer* original = new CPointer(  );
	original->Set( 2 );

	CPointer* copy = new CPointer(  );
	copy->Set( 5 );

	original->Display(); // Output: 2
	copy->Display(); // Output: 5

	*copy = *original;

	original->Display(); // Output: 2
	copy->Display(); // Output: 2

	copy->Set( 3 );

	original->Display(); // Output: 2
	copy->Display(); // Output: 3

	original->Set( 9 );

	original->Display(); // Output: 9
	copy->Display(); // Output: 3
	system( "pause" );
}

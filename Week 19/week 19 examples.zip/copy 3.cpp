// Demonstration of the need for a user created copy constructor
// Error caused by shallow copy.

#include <iostream>
using namespace std;

class CPointer
{
private:
	int* mpData;
public:
	CPointer( )
		{	mpData = new int; };
	void Set( int data )
		{	*mpData = data; };
	void Display( )
		{	cout << *mpData << endl; };
};

void main()
{
	CPointer* original = new CPointer(  );
	original->Set( 2 );

	CPointer* copy = new CPointer(  );
	*copy = *original;

	original->Display(); // Output: 2
	copy->Display(); // Output: 2

	copy->Set( 3 );

	original->Display(); // Output: 3
	copy->Display(); // Output: 3

	system( "pause" );
}
